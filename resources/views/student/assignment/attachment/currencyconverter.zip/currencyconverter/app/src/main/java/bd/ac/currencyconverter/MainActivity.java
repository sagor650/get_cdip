package bd.ac.currencyconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    String[] currency;

    double[] rate={1,0.69881,0.61095,0.93188,0.96680,44.72,73.14,80.55};
    private Spinner SpinnerFrom;
    private Spinner SpinnerTo;
    public Button convert;
    public Button clear;
    public Button swap;
    private TextView result;
    public String from;
    public String to;
    public EditText amount;
    public double d;
    public double a;
    public String s;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result=(TextView) findViewById(R.id.result) ;
        currency=getResources().getStringArray(R.array.currency);
        SpinnerFrom= (Spinner) findViewById(R.id.from);
        SpinnerTo= (Spinner) findViewById(R.id.to);
        final ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,R.layout.sample_view,R.id.TextViewSampleFrom,currency);
        SpinnerFrom.setAdapter(adapter);
        ArrayAdapter<String> adapter1 =new ArrayAdapter<String>(this,R.layout.sample_view,R.id.TextViewSampleTo,currency);
        SpinnerTo.setAdapter(adapter1);

        convert=(Button) findViewById(R.id.convert);
        clear=(Button) findViewById(R.id.clear);
        swap=(Button) findViewById(R.id.swap);
        amount= (EditText) findViewById(R.id.ammount);







        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                amount.setText("");
                result.setText("");

            }

        });


        convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int positionFrom= SpinnerFrom.getSelectedItemPosition();
                int positionTo= SpinnerTo.getSelectedItemPosition();
                from =SpinnerFrom.getSelectedItem().toString();
                to=SpinnerTo.getSelectedItem().toString();

                s= amount.getText().toString();
                a= Double.parseDouble(s);



                String v=String.valueOf(convert(positionFrom,positionTo,a));
                result.setText(v);





            }
        });


        swap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int SpinnerFromPos=SpinnerFrom.getSelectedItemPosition();
                int SpinnerToPos=SpinnerTo.getSelectedItemPosition();
                SpinnerFrom.setSelection(SpinnerToPos);
                SpinnerTo.setSelection(SpinnerFromPos);



                int positionFrom= SpinnerFrom.getSelectedItemPosition();
                int positionTo= SpinnerTo.getSelectedItemPosition();
                from =SpinnerFrom.getSelectedItem().toString();
                to=SpinnerTo.getSelectedItem().toString();

                s= amount.getText().toString();
                a= Double.parseDouble(s);
                String v=String.valueOf(convert(positionFrom,positionTo,a));
                result.setText(v);


            }
        });




    }
    private double convert(int from,int to, double amount){

        if(from==0)
            return amount*rate[to];
        else if(to==0)
            return amount/rate[from];
        double usAmount = amount / rate[from];
        return usAmount*rate[to];


    }



}
